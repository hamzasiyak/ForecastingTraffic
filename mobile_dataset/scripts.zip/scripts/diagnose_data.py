# ============================================
# diagnose_data.py  —  Milano CDR ham veri teşhisi
# ============================================
import os, glob
import pandas as pd
import numpy as np

RAW_PATH = "./data/raw"   # ham csv'ler scripts klasörünün üstünde
OUT_DIR  = "./results/diagnostics"
os.makedirs(OUT_DIR, exist_ok=True)

def read_one(path):
    df = pd.read_csv(path)
    # sütunları normalize etmeden önce raporlayacağız; sonra kopya üstünde rename
    cols_org = list(df.columns)
    df.columns = [c.strip().lower() for c in df.columns]
    # beklenen üçlü: datetime, cellid, internet (senin ekran görüntünde böyleydi)
    # ama gene de esneklik:
    col_time = next((c for c in df.columns if c in ["datetime","time","timestamp","time_interval"]), None)
    col_cell = next((c for c in df.columns if c in ["cellid","cell_id","square_id","square","cell"]), None)
    col_net  = next((c for c in df.columns if "internet" in c), None)
    return df, cols_org, col_time, col_cell, col_net

# 1) dosya keşfi
files = sorted(glob.glob(os.path.join(RAW_PATH, "sms-call-internet-mi-2013-11-*.csv")))
print(f"Bulunan dosya sayısı: {len(files)}")
pd.Series(files).to_csv(os.path.join(OUT_DIR, "file_list.csv"), index=False, header=["files"])

if not files:
    raise SystemExit("❌ CSV bulunamadı. RAW_PATH veya dosya desenini kontrol et.")

# 2) sütun tutarlılığı (dosya bazında)
report_cols = []
mini_heads  = []

for f in files:
    df, cols_org, ctime, ccell, cnet = read_one(f)
    report_cols.append({
        "file": os.path.basename(f),
        "orig_columns": "|".join(cols_org),
        "lower_columns": "|".join(df.columns),
        "time_col_found": ctime,
        "cell_col_found": ccell,
        "net_col_found":  cnet,
        "n_rows": len(df)
    })
    mini_heads.append(df.head(3).assign(__file=os.path.basename(f)))

pd.DataFrame(report_cols).to_csv(os.path.join(OUT_DIR, "column_consistency.csv"), index=False)
pd.concat(mini_heads, ignore_index=True).to_csv(os.path.join(OUT_DIR, "samples_head.csv"), index=False)

# 3) birleşik (yalnızca üç kritik sütunu alarak, değişiklik yapmadan)
parts = []
for f in files:
    df, _, ctime, ccell, cnet = read_one(f)
    if not all([ctime, ccell, cnet]):
        raise SystemExit(f"❌ Zorunlu sütun bulunamadı: {os.path.basename(f)} -> time:{ctime}, cell:{ccell}, net:{cnet}")
    tmp = df[[ctime, ccell, cnet]].copy()
    tmp.columns = ["time", "cell_id", "internet"]
    parts.append(tmp)

full = pd.concat(parts, ignore_index=True)

# tip ve sıralama
full["time"] = pd.to_datetime(full["time"])
full = full.sort_values(["cell_id", "time"]).reset_index(drop=True)

# 4) genel zaman kapsamı & frekans
t_min, t_max = full["time"].min(), full["time"].max()
# tüm farklardan mod alarak baskın frekansı bul (ilk 1e6 farkla sınırla)
deltas = full.groupby("cell_id")["time"].diff().dropna()
if len(deltas) > 0:
    mode_freq = deltas.value_counts().idxmax()
else:
    mode_freq = pd.Timedelta(minutes=10)  # varsayım
freq_minutes = int(mode_freq.total_seconds() // 60)

# 5) boş ve tekrar kayıt kontrolü
dupes = full.duplicated(subset=["cell_id","time"], keep=False)
n_dupes = dupes.sum()
n_na = full[["time","cell_id","internet"]].isna().sum()

# 6) hücre kapsam analizi (beklenen zaman noktası sayısı)
# zaman çizelgesini global zaman gridine oturtup, her hücredeki mevcut oranı ölçelim
# önce global grid:
time_grid = pd.date_range(start=t_min, end=t_max, freq=f"{freq_minutes}min")
expected_len = len(time_grid)

coverage_rows = []
for cid, g in full.groupby("cell_id"):
    present = g["time"].nunique()
    cov = present / expected_len
    coverage_rows.append({"cell_id": cid, "present": present, "expected": expected_len, "coverage_ratio": round(cov, 4)})

coverage = pd.DataFrame(coverage_rows).sort_values("coverage_ratio", ascending=False)
coverage.to_csv(os.path.join(OUT_DIR, "cell_coverage.csv"), index=False)

# 7) en sağlıklı hücre önerisi
top_cells = coverage.head(10)
top_cells.to_csv(os.path.join(OUT_DIR, "top_cells.csv"), index=False)

# 8) özet rapor
summary = {
    "files_count": len(files),
    "rows_total": len(full),
    "time_min": str(t_min),
    "time_max": str(t_max),
    "dominant_freq_minutes": freq_minutes,
    "duplicates": int(n_dupes),
    "na_time": int(n_na["time"]),
    "na_cell_id": int(n_na["cell_id"]),
    "na_internet": int(n_na["internet"]),
    "cells_total": full["cell_id"].nunique()
}
pd.DataFrame([summary]).to_csv(os.path.join(OUT_DIR, "summary.csv"), index=False)

print("✅ Teşhis tamam. Raporlar:")
print(f" - {OUT_DIR}/summary.csv")
print(f" - {OUT_DIR}/column_consistency.csv")
print(f" - {OUT_DIR}/samples_head.csv")
print(f" - {OUT_DIR}/cell_coverage.csv")
print(f" - {OUT_DIR}/top_cells.csv")
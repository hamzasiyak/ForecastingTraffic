import pandas as pd
import glob
import os
import matplotlib.pyplot as plt
import seaborn as sns
from typing import List, Optional

class DataPreparation:
    def __init__(self, data_path: str):
        self.data_path = data_path
        self.df = None

    def load_and_merge_data(self) -> pd.DataFrame:
        """Tüm CSV dosyalarını yükler ve birleştirir"""
        all_files = glob.glob(os.path.join(self.data_path, "sms-call-internet-mi-*.csv"))
        
        df_list = []
        for filename in sorted(all_files):
            # Her bir CSV dosyasını oku
            df = pd.read_csv(filename)
            
            # datetime sütununun formatını kontrol et ve dönüştür
            print(f"\nProcessing file: {filename}")
            print(f"Sample datetime value: {df['datetime'].iloc[0]}")
            
            # datetime sütununu dönüştür
            try:
                df['datetime'] = pd.to_datetime(df['datetime'])
                print("✅ Datetime conversion successful")
            except Exception as e:
                print(f"❌ Error converting datetime: {e}")
                print(f"Data type: {df['datetime'].dtype}")
                print(f"Sample values:\n{df['datetime'].head()}")
                raise
            
            df_list.append(df)
        
        # Tüm dataframe'leri birleştir
        self.df = pd.concat(df_list, axis=0, ignore_index=True)
        
        # Tarihe göre sırala
        self.df.sort_values('datetime', inplace=True)
        
        # Bilgi göster
        print("\nDataset Info:")
        print(f"Total rows: {len(self.df)}")
        print(f"Date range: {self.df['datetime'].min()} to {self.df['datetime'].max()}")
        
        return self.df

    def clean_data(self) -> pd.DataFrame:
        """Enhanced data cleaning with better handling of outliers and missing values"""
        # Handle missing values by cell and country
        for col in ['smsin', 'smsout', 'callin', 'callout', 'internet']:
            # Fill missing values with cell & time based means
            self.df[col] = self.df.groupby(['CellID', 'countrycode'])[col].transform(
                lambda x: x.fillna(x.mean())
            )
        
        # Handle outliers using IQR method for internet usage
        Q1 = self.df['internet'].quantile(0.25)
        Q3 = self.df['internet'].quantile(0.75)
        IQR = Q3 - Q1
        self.df['internet_cleaned'] = self.df['internet'].clip(
            lower=Q1 - 1.5 * IQR,
            upper=Q3 + 1.5 * IQR
        )
        
        print("\nOutlier Analysis:")
        print(f"Original internet range: {self.df['internet'].min():.2f} to {self.df['internet'].max():.2f}")
        print(f"Cleaned internet range: {self.df['internet_cleaned'].min():.2f} to {self.df['internet_cleaned'].max():.2f}")
        
        return self.df

    def create_time_features(self) -> pd.DataFrame:
        """Enhanced time features with aggregations"""
        # Basic time features
        self.df['hour'] = self.df['datetime'].dt.hour
        self.df['day'] = self.df['datetime'].dt.day
        self.df['weekday'] = self.df['datetime'].dt.weekday
        
        # Advanced features
        self.df['is_weekend'] = self.df['weekday'].isin([5, 6]).astype(int)
        self.df['is_peak_hour'] = self.df['hour'].between(9, 17).astype(int)
        
        # Rolling statistics per cell
        self.df['rolling_mean'] = self.df.groupby('CellID')['internet_cleaned'].transform(
            lambda x: x.rolling(window=6, min_periods=1).mean()
        )
        
        return self.df

    def plot_basic_visualizations(self):
        """Enhanced visualizations"""
        plt.figure(figsize=(15, 20))
        
        # Internet usage distribution
        plt.subplot(4, 1, 1)
        sns.histplot(data=self.df, x='internet_cleaned', bins=50)
        plt.title('Distribution of Internet Usage (Cleaned)')
        plt.xlabel('Internet Usage')
        
        # Daily patterns
        plt.subplot(4, 1, 2)
        daily_avg = self.df.groupby('hour')['internet_cleaned'].mean()
        daily_avg.plot(kind='line', marker='o')
        plt.title('Average Internet Usage by Hour')
        plt.xlabel('Hour of Day')
        plt.ylabel('Average Usage')
        
        # Weekend vs Weekday
        plt.subplot(4, 1, 3)
        sns.boxplot(data=self.df, x='is_weekend', y='internet_cleaned')
        plt.title('Internet Usage: Weekend vs Weekday')
        plt.xlabel('Weekend (1) vs Weekday (0)')
        
        # Top cells by usage
        plt.subplot(4, 1, 4)
        top_cells = self.df.groupby('CellID')['internet_cleaned'].mean().nlargest(10)
        top_cells.plot(kind='bar')
        plt.title('Top 10 Cells by Average Internet Usage')
        plt.xticks(rotation=45)
        
        plt.tight_layout()
        plt.savefig('../reports/figures/enhanced_analysis.png')
        plt.close()

def main():
    # Create directory for outputs
    os.makedirs('../reports/figures', exist_ok=True)
    
    # Data preparation
    data_prep = DataPreparation('../mobile_dataset/data/raw')
    df = data_prep.load_and_merge_data()
    
    # Print sample data for debugging
    print("\nFirst few rows of the dataset:")
    print(df.head())
    
    df = data_prep.clean_data()
    df = data_prep.create_time_features()
    
    # Basic statistics
    print("\nSummary statistics for internet usage:")
    print(df['internet'].describe())
    
    # Visualizations
    data_prep.plot_basic_visualizations()

if __name__ == "__main__":
    main()
# ============================================
# Milano CDR Internet Traffic Preparer (Fixed Columns)
# ============================================

import pandas as pd
import glob
import os
import matplotlib.pyplot as plt

RAW_PATH = "./data/raw"  # CSV'ler scripts klasörünün üst dizininde
PROCESSED_PATH = "./data/processed/"
RESULTS_PATH = "./results/"

os.makedirs(PROCESSED_PATH, exist_ok=True)
os.makedirs(RESULTS_PATH, exist_ok=True)

# ------------------------------
# 1. Dosyaları oku ve birleştir
# ------------------------------
files = glob.glob(os.path.join(RAW_PATH, "sms-call-internet-mi-2013-11-*.csv"))
print(f"{len(files)} adet dosya bulundu.")

dfs = []
for f in sorted(files):
    print(f"→ {os.path.basename(f)} okunuyor...")
    data = pd.read_csv(f)
    data.columns = [c.strip().lower() for c in data.columns]
    # Gereken sütunları seç
    df_part = data[['datetime', 'cellid', 'internet']].copy()
    df_part.rename(columns={
        'datetime': 'time_interval',
        'cellid': 'square_id',
        'internet': 'internet_traffic'
    }, inplace=True)
    dfs.append(df_part)

# ------------------------------
# 2. Tek veri seti haline getir
# ------------------------------
df = pd.concat(dfs, ignore_index=True)
df['time_interval'] = pd.to_datetime(df['time_interval'])
df = df.sort_values('time_interval')

print("\n✅ Veri başarıyla birleştirildi:")
print(df.head())

# ------------------------------
# 3. Ortalama trafik hesapla
# ------------------------------
df_mean = df.groupby('time_interval')['internet_traffic'].mean().reset_index()

# ------------------------------
# 4. Görselleştir
# ------------------------------
plt.figure(figsize=(10,4))
plt.plot(df_mean['time_interval'], df_mean['internet_traffic'], color='orange')
plt.title("Average Internet Traffic Across All Cells")
plt.xlabel("Time")
plt.ylabel("Average Traffic Load")
plt.grid(True)
plt.tight_layout()
plt.savefig(os.path.join(RESULTS_PATH, "average_traffic.png"))
plt.close()

print("\n✅ Ortalama trafik grafiği kaydedildi (results/average_traffic.png).")

# ------------------------------
# 5. Veriyi kaydet
# ------------------------------
processed_file = os.path.join(PROCESSED_PATH, "milano_internet_combined.csv")
df.to_csv(processed_file, index=False)
print(f"✅ Temiz veri kaydedildi: {processed_file}")
